NASSAU CANDY DISTRIBUTOR — POWER BI PROJECT PACK

Included:
- Nassau_Candy_Distributor_PowerBI.csv: import-ready dataset with ISO-formatted dates
- PowerBI_Dashboard_Build_Guide.docx: report pages, slicers, and implementation steps
- PowerBI_DAX_Measures.txt: core measures and margin-threshold starter logic
- PowerBI_PowerQuery_M.txt: Power Query type-conversion starter (update the local file path)
- Nassau_Candy_PowerBI_Theme.json: importable theme
- Nassau_Candy_Profitability_Research_Paper.pdf/.docx: EDA, results, limitations, recommendations
- Nassau_Candy_Executive_Summary.pdf/.docx: concise stakeholder summary
- Visual assets: division comparison, Pareto, cost vs sales

Important:
This pack is designed for Microsoft Power BI Desktop. It does not include a native .pbix file or hosted live report URL because those must be saved/published from Power BI Desktop in an account/workspace. Follow the guide, then Save As .pbix and publish if your workspace allows it.

Validation notes:
- Gross profit measures gross profit based on the provided Sales and Cost fields.
- The 20% margin screen is illustrative and should be replaced by a management-approved target.
- Verify the date columns and reconcile totals with the source system before operational use.
